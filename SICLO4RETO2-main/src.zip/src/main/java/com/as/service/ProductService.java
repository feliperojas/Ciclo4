package com.as.service;

import com.as.model.Product;
import com.as.repository.ProductRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * MISION TIC 2022
 */
@Service
public class ProductService {

    @Autowired
    private ProductRepository repositorio;

    public List<Product> listAll() {
        return repositorio.listAll();
    }

    public Optional<Product> getAccesory(String reference) {
        return repositorio.getAccesory(reference);
    }

    public Product create(Product accesory) {
        if (accesory.getReference() == null) {
            return accesory;
        } else {
            return repositorio.create(accesory);
        }
    }

    public Product update(Product accesory) {

        if (accesory.getReference() != null) {
            Optional<Product> accesoryDb = repositorio.getAccesory(accesory.getReference());
            if (!accesoryDb.isEmpty()) {
                if (accesory.getBrand() != null) {
                    accesoryDb.get().setBrand(accesory.getBrand());
                }

                if (accesory.getCategory() != null) {
                    accesoryDb.get().setCategory(accesory.getCategory());
                }


                if (accesory.getDescription() != null) {
                    accesoryDb.get().setDescription(accesory.getDescription());
                }
                if (accesory.getPrice() != 0.0) {
                    accesoryDb.get().setPrice(accesory.getPrice());
                }
                if (accesory.getQuantity() != 0) {
                    accesoryDb.get().setQuantity(accesory.getQuantity());
                }
                if (accesory.getPhotography() != null) {
                    accesoryDb.get().setPhotography(accesory.getPhotography());
                }
                accesoryDb.get().setAvailability(accesory.isAvailability());
                repositorio.update(accesoryDb.get());
                return accesoryDb.get();
            } else {
                return accesory;
            }
        } else {
            return accesory;
        }
    }

    public boolean delete(String reference) {
        Boolean aBoolean = getAccesory(reference).map(accesory -> {
            repositorio.delete(accesory);
            return true;
        }).orElse(false);
        return aBoolean;
    }
}
