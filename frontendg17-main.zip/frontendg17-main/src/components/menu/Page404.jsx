import React from 'react'
import '../../assets/css/style.css'
const Page404 = () => {
    return (
        <div className="page404 jumbotron">
            <h1 className="text-center">Pagina no Encontrada</h1>
        </div>
    )
}

export default Page404
